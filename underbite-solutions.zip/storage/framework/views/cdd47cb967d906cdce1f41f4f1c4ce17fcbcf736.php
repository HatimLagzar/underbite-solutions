<?php $__env->startSection('title'); ?>
    <?php echo e(__('Home')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section id="hero">
        <div id="carouselExampleSlidesOnly" class="carousel slide carousel-fade" data-bs-ride="carousel"
             data-bs-config='{"interval":3500}'>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="/images/hero.jpeg" class="d-block" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="/images/about_us.jpeg" class="d-block" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="/images/img-service.jpeg" class="d-block" alt="Slide 3">
                </div>
            </div>
        </div>
        <div class="container">
            <h1><?php echo e(__('Care for your smile')); ?></h1>
            <div class="row">
                <div class="col-lg-5 col-12">
                    <p><?php echo e(__('Your smile is one of the important things for your and we care about this, that’s why we gathered to help you fix this problem and make your life easier.')); ?></p>
                    <a href="/#form-wrapper" class="btn btn-primary rounded-5 apply"><?php echo e(__('Apply & Meet Us')); ?></a>
                </div>
            </div>
        </div>
    </section>

    <section id="form-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-12">
                    <div class="d-flex flex-column justify-content-between">
                        <h2 class="title text-center"><?php echo e(__('Fully sponsored by us')); ?></h2>
                        <p class="text-center"><?php echo e(__('For all nationalities and countries')); ?></p>
                        <div class="circle-wrapper">
                            <div id="circle">
                                <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <linearGradient id="circleGradient" gradientTransform="rotate(90)">
                                            <stop offset="0%" stop-color="white"/>
                                            <stop offset="50%" stop-color="#ffffff40"/>
                                            <stop offset="100%" stop-color="white"/>
                                        </linearGradient>
                                    </defs>
                                    <circle cx="50" cy="50" r="49" fill="none" stroke="url(#circleGradient)"
                                            stroke-width="0.3"
                                            stroke-dasharray="2 1.5"/>
                                </svg>
                                <p id="free-of-charges"
                                   class="text-center position-absolute top-50"><?php echo __('100% <br> free of charges'); ?></p>
                                <div class="top">
                                    <div class="left">
                                        <span class=""><?php echo e(__('Follow-ups')); ?></span>
                                        <i class="fa fa-calendar-check-o"></i>
                                    </div>
                                    <div class="center">
                                        <span class="d-block"><?php echo e(__('Medication')); ?></span>
                                        <i class="fa fa-medkit text-center d-block"></i>
                                    </div>
                                    <div class="right travel-area">
                                        <i class="fa fa-plane"></i>
                                        <div class="travel-text lh-1">
                                            <span class="d-md-block text-start"><?php echo e(__('Travel')); ?></span>
                                            <span class="text-start lh-sm w-75 d-block"
                                                  style="font-size: 10px"><?php echo e(__('Flights, Hotel, food and medical visa')); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="bottom">
                                    <div class="left">
                                        <span class=""><?php echo e(__('Surgery')); ?></span>
                                        <i class="fa fa-medkit"></i>
                                    </div>
                                    <div class="center">
                                        <img src="<?php echo e(asset('images/icons/braces.svg')); ?>" alt="braces">
                                        <span class="mt-1"><?php echo e(__('Braces')); ?></span>
                                    </div>
                                    <div class="right">
                                        <i class="fa fa-heart"></i>
                                        <span class=""><?php echo e(__('Consultation')); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p class="fs-3 text-center mt-2 mb-2"><?php echo e(__('No Insurance Required')); ?></p>
                        <p class="text-center mb-0"><?php echo e(__('for 95% of cases')); ?></p>
                    </div>
                </div>
                <div class="col-lg-1 d-lg-block d-none"></div>
                <div class="col-lg-6 col-12 apply-col" style="margin-top: -200px;">
                    <div id="apply-now" class="apply-wrapper">
                        <form method="POST" action="#">
                            <h4 class="text-pink mb-0"><?php echo e(__('Book your visit at')); ?></h4>
                            <h3 class="text-blue border-bottom"><?php echo e(__('Denistry Care')); ?></h3>
                            <div class="row">
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="firstNameInput"><?php echo e(__('First Name')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <input id="firstNameInput" type="text" class="form-control" name="first_name"
                                           required>
                                </div>
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="lastNameInput"><?php echo e(__('Last Name')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <input id="lastNameInput" type="text" class="form-control" name="last_name"
                                           required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="genderInput"><?php echo e(__('Your Gender')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <select id="genderInput" class="form-select" name="gender" required>
                                        <option value=""><?php echo e(__('Select Gender')); ?></option>
                                        <option value="1"><?php echo e(__('Male')); ?></option>
                                        <option value="2"><?php echo e(__('Female')); ?></option>
                                    </select>
                                </div>
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="ageInput"><?php echo e(__('Your Age')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <select
                                        onblur='this.size=5;'
                                        onfocusout='this.size=null;'
                                        id="ageInput" type="text"  class=" form-select"
                                        name="age"
                                        required>
                                        <option value=""><?php echo e(__('Select Age')); ?></option>
                                        <?php for($i = 16; $i <= 50; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="heightInput"><?php echo e(__('Your Height')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <select
                                        onblur='this.size=5;'
                                        onfocusout='this.size=null;'
                                        id="heightInput"
                                        type="text"

                                        class="selectHeight form-select"
                                        required
                                        name="height">
                                        <option value=""><?php echo e(__('Select Height')); ?></option>
                                        <?php if($countryCode && in_array($countryCode, ['US', 'LR', 'MM'])): ?>
                                            <?php for($i = 120; $i <= 210; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e(turnCentimeterToFoot($i)); ?>" ft</option>
                                            <?php endfor; ?>
                                        <?php else: ?>
                                            <?php for($i = 120; $i <= 210; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?> cm</option>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="weightInput"><?php echo e(__('Your Weight')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <select
                                        onblur='this.size=5;'
                                        onfocusout='this.size=null;'
                                        id="weightInput"
                                        type="text"
                                        required
                                        class="selectWeight form-select"
                                        name="weight">
                                        <option value=""><?php echo e(__('Select Weight')); ?></option>
                                        <?php if($countryCode && in_array($countryCode, ['US', 'LR', 'MM'])): ?>
                                            <?php for($i = 30; $i <= 130; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e(turnKilogramToLbs($i)); ?> pound</option>
                                            <?php endfor; ?>
                                        <?php else: ?>
                                            <?php for($i = 30; $i <= 130; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?> Kg</option>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="emailInput"><?php echo e(__('Your Email')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>

                                            )</small></label>
                                    <input id="emailInput" type="email" class="form-control" name="email" required>
                                </div>
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="countryInput"><?php echo e(__('Your Origin/Country')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>)</small></label>
                                    <select

                                        onblur='this.size=5;'
                                        onfocusout='this.size=null;'
                                        id="countryInput" type="text" class="form-select" name="country" required>
                                        <option value=""><?php echo e(__('Select Country')); ?></option>
                                        <?php $__currentLoopData = \App\Models\Country::orderBy(\App\Models\Country::NAME_COLUMN, 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value="<?php echo e($country->getCode()); ?>"><?php echo e($country->getName()); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="phoneInput"><?php echo e(__('Phone Number')); ?> <small
                                            class="text-muted"
                                            style="font-size: 12px;">(<?php echo e(__('Required')); ?>)</small></label>
                                    <input id="phoneInput" type="tel" class="form-control" name="phone_number" required>
                                </div>

                                <div class="form-group col-12 col-lg-6 mb-3">
                                    <label class="form-label" for="sourceInput">
                                        <?php echo e(__('Where did you hear abour us?')); ?>

                                    </label>
                                    <select
                                        onblur='this.size=5;'
                                        onfocusout='this.size=null;'
                                        onchange='this.size=5; this.blur();'
                                        id="sourceInput"
                                        class="selectOption form-select"
                                        name="hearing_about_us_source"
                                        required
                                    >
                                        <option value=""><?php echo e(__('Select Option')); ?></option>
                                        <option
                                            value="SEARCH_ENGINE"><?php echo e(__('Search Engine (Google, Yahoo, Bing...)')); ?></option>
                                        <option value="FACEBOOK"><?php echo e(__('Facebook')); ?></option>
                                        <option value="INSTAGRAM"><?php echo e(__('Instagram')); ?></option>
                                        <option value="YOUTUBE"><?php echo e(__('YouTube')); ?></option>
                                        <option value="TIKTOK"><?php echo e(__('TikTok')); ?></option>
                                        <option value="BLOG_POST"><?php echo e(__('Blog Post')); ?></option>
                                        <option value="CONFERENCE"><?php echo e(__('Conference')); ?></option>
                                        <option
                                            value="FRIEND"><?php echo e(__('From a friend, family member, or coworker')); ?></option>
                                    </select>
                                </div>
                            </div>


                            <h4 class="text-center mb-0 mt-4"><?php echo e(__('Upload photos of your underbite')); ?></h4>
                            <p
                                class="text-danger text-center"><?php echo e(__('Please make sure your teeth are fully visible in all photos')); ?></p>

                            <div class="row uploads">
                                <div class="col-6 col-sm-3">
                                    <input type="file" name="front_side" id="frontSideInput"
                                           data-text="<?php echo e(__('Front View')); ?>"
                                           class="visually-hidden" accept="image/*" required>
                                    <label for="frontSideInput" class="position-relative w-100 d-block d-lg-none">
                                        <img class="d-block mx-auto" src="/images/icons/front.svg"
                                             data-src="/images/icons/front.svg"
                                             alt="Front View">
                                        <span class="bg-white add-icon-wrapper">
                      <i class="fa fa-plus"></i>
                    </span>
                                    </label>
                                    <div class="dropdown d-lg-block d-none" data-target="frontSideInput">
                                        <button class="p-0 border-0" type="button" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            <img class="d-block mx-auto" src="/images/icons/front.svg"
                                                 data-src="/images/icons/front.svg"
                                                 alt="Front View">
                                            <span class="bg-white add-icon-wrapper">
                        <i class="fa fa-plus"></i>
                      </span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <label for="frontSideInput"
                                                       class="dropdown-item position-relative w-100">
                                                    <i class="fa fa-upload me-1"></i><?php echo e(__('Upload')); ?>

                                                </label>
                                            </li>
                                            <li>
                                                <button type="button" class="dropdown-item request-take-picture-btn">
                                                    <i class="fa fa-camera me-1"></i><?php echo e(__('Take Picture')); ?>

                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                    <p class="text-black text-center mt-1 mb-0"><?php echo e(__('Front View')); ?></p>
                                    <small
                                        class="text-muted text-danger text-center d-block mb-3"><?php echo e(__('(required)')); ?></small>
                                </div>
                                <div class="col-6 col-sm-3">
                                    <input type="file" name="right_side" id="rightSideInput"
                                           data-text="<?php echo e(__('Right View')); ?>"
                                           class="visually-hidden" accept="image/*" required>
                                    <label for="rightSideInput" class="position-relative w-100 d-block d-lg-none">
                                        <img class="d-block mx-auto" src="/images/icons/right.svg"
                                             data-src="/images/icons/right.svg"
                                             alt="Right View">
                                        <span class="bg-white add-icon-wrapper">
                      <i class="fa fa-plus"></i>
                    </span>
                                    </label>
                                    <div class="dropdown d-lg-block d-none" data-target="rightSideInput">
                                        <button class="p-0 border-0" type="button" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            <img class="d-block mx-auto" src="/images/icons/right.svg"
                                                 data-src="/images/icons/right.svg"
                                                 alt="Right View">
                                            <span class="bg-white add-icon-wrapper">
                        <i class="fa fa-plus"></i>
                      </span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <label for="rightSideInput"
                                                       class="dropdown-item position-relative w-100">
                                                    <i class="fa fa-upload me-1"></i><?php echo e(__('Upload')); ?>

                                                </label>
                                            </li>
                                            <li>
                                                <button type="button" class="dropdown-item request-take-picture-btn">
                                                    <i class="fa fa-camera me-1"></i><?php echo e(__('Take Picture')); ?>

                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                    <p class="text-black text-center mt-1 mb-0"><?php echo e(__('Right Side')); ?></p>
                                    <small
                                        class="text-muted text-danger text-center d-block mb-3"><?php echo e(__('(required)')); ?></small>
                                </div>
                                <div class="col-6 col-sm-3">
                                    <input type="file" name="right_closed" id="rightClosedSideInput"
                                           data-text="<?php echo e(__('Right View Closed')); ?>" class="visually-hidden"
                                           accept="image/*" required>
                                    <label for="rightClosedSideInput" class="position-relative w-100 d-block d-lg-none">
                                        <img class="d-block mx-auto" src="/images/icons/right-closed.svg"
                                             data-src="/images/icons/right-closed.svg" alt="Right Closed">
                                        <span class="bg-white add-icon-wrapper">
                      <i class="fa fa-plus"></i>
                    </span>
                                    </label>
                                    <div class="dropdown d-lg-block d-none" data-target="rightClosedSideInput">
                                        <button class="p-0 border-0" type="button" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            <img class="d-block mx-auto" src="/images/icons/right-closed.svg"
                                                 data-src="/images/icons/right-closed.svg" alt="Right Closed">
                                            <span class="bg-white add-icon-wrapper">
                        <i class="fa fa-plus"></i>
                      </span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <label for="rightClosedSideInput"
                                                       class="dropdown-item position-relative w-100">
                                                    <i class="fa fa-upload me-1"></i><?php echo e(__('Upload')); ?>

                                                </label>
                                            </li>
                                            <li>
                                                <button type="button" class="dropdown-item request-take-picture-btn">
                                                    <i class="fa fa-camera me-1"></i><?php echo e(__('Take Picture')); ?>

                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                    <p class="text-black text-center mt-1 mb-0"><?php echo e(__('Right Closed')); ?></p>
                                    <small
                                        class="text-muted text-danger text-center d-block mb-3"><?php echo e(__('(required)')); ?></small>
                                </div>
                                <div class="col-6 col-sm-3">
                                    <input type="file" name="front_closed" id="frontClosedInput"
                                           data-text="<?php echo e(__('Front View Closed')); ?>"
                                           class="visually-hidden" accept="image/*" required>
                                    <label for="frontClosedInput" class="position-relative w-100 d-block d-lg-none">
                                        <img class="d-block mx-auto" src="/images/icons/front-closed.svg"
                                             data-src="/images/icons/front-closed.svg"
                                             alt="<?php echo e(__('Front View Closed')); ?>">
                                        <span class="bg-white add-icon-wrapper">
                      <i class="fa fa-plus"></i>
                    </span>
                                    </label>
                                    <div class="dropdown d-lg-block d-none" data-target="frontClosedInput">
                                        <button class="p-0 border-0" type="button" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            <img class="d-block mx-auto" src="/images/icons/front-closed.svg"
                                                 data-src="/images/icons/front-closed.svg" alt="Perspective View">
                                            <span class="bg-white add-icon-wrapper">
                        <i class="fa fa-plus"></i>
                      </span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <label for="frontClosedInput"
                                                       class="dropdown-item position-relative w-100">
                                                    <i class="fa fa-upload me-1"></i><?php echo e(__('Upload')); ?>

                                                </label>
                                            </li>
                                            <li>
                                                <button type="button" class="dropdown-item request-take-picture-btn">
                                                    <i class="fa fa-camera me-1"></i><?php echo e(__('Take Picture')); ?>

                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                    <p class="text-black text-center mt-1 mb-0"><?php echo e(__('Front Closed')); ?></p>
                                    <small
                                        class="text-muted text-danger text-center d-block mb-3"><?php echo e(__('(required)')); ?></small>
                                </div>
                            </div>

                            <p
                                class="text-sm text-black text-center"><?php echo e(__('Note: By sharing your information with us, you are agreeing to give us permissions to review your information, All content will remain highly confidential.')); ?></p>

                            <p id="error-feedback" class="text-danger text-center mb-1"></p>
                            <p id="success-feedback" class="text-center text-success mb-1"></p>

                            <button type="submit"
                                    class="btn btn-primary rounded-5 mx-auto d-block"><?php echo e(__('Apply')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="specialized-team" style="padding-bottom: 2px; padding-top: 40px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-sm-6">
                    <h2 class="text-center text-blue"><?php echo e(__('Specialized Team')); ?></h2>
                    <div class="separator"></div>
                    <p class="quote">
                        "<?php echo e(__('We are a team or dentists, hygienists and receptionists who work togetner to ensure that you receive the best treatment that you require at a very time that suits you.')); ?>

                        "</p>
                    <img class="mx-auto d-block" src="/images/img-signature.png" alt="Signature">
                </div>
                <div class="col-1 d-none d-sm-block"></div>
                <div class="col-12 col-sm-5 mt-5">
                    <figure>
                        <img class="w-100" src="/images/img-service.jpeg" alt="Image Service">
                        <figcaption
                            class="text-center text-pink fs-5 mt-2"><?php echo __("Class 3 malocclusion<br><small class='text-sm'>(Underbite or double jaw)</small>"); ?></figcaption>
                    </figure>
                </div>
            </div>
        </div>
    </section>

    <section id="international-program">
        <div class="separator-line"></div>
        <h2 class="text-center"><?php echo e(__('International Program')); ?></h2>
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <h4 class="text-center"><?php echo e(__('Countries from all countries accepted')); ?></h4>
                    <img class="mx-auto d-block mt-2 mb-4" src="/images/world.png" alt="World Map">
                </div>
                <div class="col-12 col-lg-6">
                    <h4 class="text-center"><?php echo e(__('Countries We Operate In')); ?></h4>
                    <ul>
                        <li><img src="/images/flags/usa.png" alt="USA"></li>
                        <li><img src="/images/flags/united-kingdom.png" alt="UK"></li>
                        <li><img src="/images/flags/united-arab-emirates.png" alt="UAE"></li>
                        <li><img src="/images/flags/germany.png" alt="germany"></li>
                    </ul>
                    <ul>
                        <li><img src="/images/flags/brazil.png" alt="brazil"></li>
                        <li><img src="/images/flags/japan.png" alt="japan"></li>
                        <li><img src="/images/flags/south-korea.png" alt="south korea"></li>
                        <li><img src="/images/flags/russia.png" alt="russia"></li>
                    </ul>
                </div>
            </div>

            <p class="mb-0 mt-0 text-center mx-auto motivation-text"
               style="width: 60%;"><?php echo e(__('Get the chance to visit your favorite country and get the treatment you need. Or if you are unable to travel we will fund your treatment with a local orthodontist.')); ?></p>
        </div>
        <img src="<?php echo e(asset('images/world_tour.svg')); ?>" alt="" loading="lazy">
    </section>

    <section id="our-dental-service">
        <h3 class="text-center text-pink fw-light mb-1"><?php echo e(__('Our Dental Service')); ?></h3>
        <h2 class="text-center fw-semibold"><?php echo e(__('Professionals')); ?></h2>
        <p
            class="text-center text-muted w-50 mx-auto mb-5"><?php echo e(__('Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate e-business applications through  revolutionary catalysts for change. Seamlessly underwhelm optimal testing processes. ')); ?></p>

        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6 mb-3">
                    <div class="item">
                        <svg class="progress-bar-svg" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="44" fill="none" stroke="#eee" stroke-width="3"/>
                            <circle class="percent p-95" cx="50" cy="50" r="44" fill="none" stroke="#0E54AE"
                                    stroke-width="3"
                                    pathLength="100"/>
                        </svg>
                        <div class="content">
                            <img src="/images/icons/thumbs-up.png" alt="Thumbs up">
                        </div>
                    </div>
                    <p class="fw-bold text-center fs-4 mb-0">95%</p>
                    <p class="fw-semibold text-center"><?php echo e(__('Patient Satisfaction')); ?></p>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="item">
                        <svg class="progress-bar-svg" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="44" fill="none" stroke="#eee" stroke-width="3"/>
                            <circle class="percent p-97" cx="50" cy="50" r="44" fill="none" stroke="#0E54AE"
                                    stroke-width="3"
                                    pathLength="100"/>
                        </svg>
                        <div class="content">
                            <img src="/images/icons/check-up.png" alt="Check Up">
                        </div>
                    </div>
                    <p class="fw-bold text-center fs-4 mb-0">97%</p>
                    <p class="fw-semibold text-center"><?php echo e(__('Dental Success')); ?></p>
                </div>
                <div class="col-md-3 col-6 mb-3 d-flex flex-column justify-content-end">
                    <div class="item">
                        <svg class="progress-bar-svg" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="44" fill="none" stroke="#eee" stroke-width="3"/>
                            <circle class="percent p-100" cx="50" cy="50" r="44" fill="none" stroke="#0E54AE"
                                    stroke-width="3"
                                    pathLength="100"/>
                        </svg>
                        <div class="content">
                            <img src="/images/icons/plane.png" alt="Plane">
                        </div>
                    </div>
                    <p class="fw-bold text-center fs-4 mb-0">100%</p>
                    <p class="fw-semibold text-center"><?php echo e(__('Travel Satisfaction')); ?></p>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="item">
                        <svg class="progress-bar-svg" viewBox="0 0 100 100">
                            <circle cx="50" cy="50" r="44" fill="none" stroke="#eee" stroke-width="3"/>
                            <circle class="percent p-96" cx="50" cy="50" r="44" fill="none" stroke="#0E54AE"
                                    stroke-width="3"
                                    pathLength="100"/>
                        </svg>
                        <div class="content">
                            <img src="/images/icons/recovery.png" alt="Recovery">
                        </div>
                    </div>
                    <p class="fw-bold text-center fs-4 mb-0">96%</p>
                    <p class="fw-semibold text-center"><?php echo e(__('Quick Recovery')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="previewSnapshotModal" tabindex="-1" aria-labelledby="previewSnapshotModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="previewSnapshotModalLabel"><?php echo e(__('Take a Photo')); ?></h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6
                        class="text-center text-white bg-danger rounded-2 p-2 mb-3"><?php echo e(__('Please make sure you are your area is well lite before taking a picture, good lighting is essential for clear photos.')); ?></h6>
                    <video id="webcam-live" class="mx-w-full" autoplay playsinline
                           style="display: block; margin: 0 auto 25px;"></video>
                    <canvas id="picture-canvas" class="d-none" style="margin: 0 auto 19px;"></canvas>
                    <div id="picture-controls" class="d-none justify-content-center">
                        <button id="retake-picture" class="btn btn-danger d-block"><i
                                class="fa fa-repeat me-1"></i><?php echo e(__('Retake')); ?>

                        </button>
                        <button id="use-picture" class="btn btn-info d-block ms-2"><i
                                class="fa fa-check me-1"></i><?php echo e(__('Use')); ?>

                        </button>
                    </div>
                    <button id="take-picture" class="btn btn-primary mx-auto d-block"><i
                            class="fa fa-camera me-1"></i><?php echo e(__('Take Picture')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/pages/home.js')); ?>"></script>













<?php $__env->stopPush(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/client/home.blade.php ENDPATH**/ ?>