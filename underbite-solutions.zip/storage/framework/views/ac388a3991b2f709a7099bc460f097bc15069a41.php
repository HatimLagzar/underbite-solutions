<?php $__env->startSection('title'); ?>
    <?php echo e(__('FAQ')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="faq" style="padding-top: 41px;padding-bottom: 45px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    
                    <h3 class="fw-semibold"><span class="underline"><?php echo e(__('FAQ')); ?></span></h3>

                    <div class="break-line"></div>

                    <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area).')); ?>

                        <br> <?php echo e(__('a message through the')); ?>

                        <?php echo e(__('a message through the')); ?><a style="text-decoration: none; color: #b0dae3;"
                                                          href="<?php echo e(route('pages.contact-us')); ?>"><?php echo e(__('contact us')); ?></a> <?php echo e(('page.')); ?>

                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="questions" class="d-flex text-center">
        <div class="container">
            <h3 class="text-pink fw-light mb-1"><?php echo e(__('Frequently Asked Questions')); ?></h3>
            <h2 class="fw-semibold text-blue"><?php echo e(__('Questions')); ?></h2>
            <div class="wrapper">
                
                <div class="containerr">
                    <div class="question">
                        <?php echo e(__('Why is visiting the dentist so important?')); ?>


                    </div>
                    <div class="answercont">
                        <div class="answer">
                            <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area)).')); ?></p>
                            <p><?php echo e(__('To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root..')); ?></p>

                        </div>
                    </div>
                </div>
                

                
                <div class="containerr">
                    <div class="question">
                        <?php echo e(__('My teeth feel fine. Do I still need to see a dentist?')); ?>


                    </div>
                    <div class="answercont">
                        <div class="answer">
                            <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area))).')); ?></p>
                            <p><?php echo e(__('To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root .')); ?></p>
                        </div>
                    </div>
                </div>
                

                
                <div class="containerr">
                    <div class="question">
                        <?php echo e(__('What should I look for when choosing the right dentist for me?')); ?>


                    </div>
                    <div class="answercont">
                        <div class="answer">
                            <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area).')); ?></p>
                            <p><?php echo e(__('q4.To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root.')); ?></p>
                        </div>
                    </div>
                </div>
                

                
                <div class="containerr">
                    <div class="question">
                        <?php echo e(__('How can I take care of my teeth between dental checkups?')); ?>

                    </div>
                    <div class="answercont">
                        <div class="answer">
                            <p><?php echo e(__('q5.Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area).')); ?></p>
                            <p><?php echo e(__('a5.To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root.')); ?></p>
                        </div>
                    </div>
                </div>
                

                
                <div class="containerr">
                    <div class="question">
                        <?php echo e(__('At what age should I start taking my child to see the dentist?')); ?>

                    </div>
                    <div class="answercont">
                        <div class="answer">
                            <p><?php echo e(__('q5.Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area).')); ?></p>
                            <p><?php echo e(__('a5.To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root.')); ?></p>
                        </div>
                    </div>
                </div>
                


            </div>


        </div>
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        

        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        

        

        
        
        

        
    </section>

    <section id="proud-members">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-12">
                    <h3><span class="text-pink fw-normal">Proud</span><span class="text-blue fw-bold">Members</span>
                    </h3>
                    <p><?php echo e(__('DentiCare prouds itself of being one empowered manufactured products whereas parallel platforms. Holisticly predominate extensible testing procedures.')); ?></p>
                </div>
                <div class="col-lg d-none d-lg-block"></div>
                <div class="col-lg-5 col-12">
                    <div class="row mb-3">
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPrepend('scripts'); ?>
    <script>


        let question = document.querySelectorAll(".question");
        console.log(question)

        question.forEach(question => {

            question.addEventListener("click", event => {
                console.log(this)
                const active = document.querySelector(".question.active");
                console.log(active)
                if (active && active !== question) {
                    active.classList.toggle("active");
                    active.nextElementSibling.style.maxHeight = 0;
                }
                question.classList.toggle("active");
                const answer = question.nextElementSibling;
                if (question.classList.contains("active")) {
                    answer.style.maxHeight = answer.scrollHeight + "px";
                } else {
                    answer.style.maxHeight = 0;
                }
            })
        })


    </script>

<?php $__env->stopPrepend(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/client/faq.blade.php ENDPATH**/ ?>