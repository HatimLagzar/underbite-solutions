<?php
    /** @var $posts \App\Models\Post[]|\Illuminate\Pagination\LengthAwarePaginator */
?>

<?php $__env->startSection('title'); ?>
    <?php echo e(__('Blog')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="blog-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <h3 class="fw-light mb-1"><?php echo e(__('Dental Surgery')); ?></h3>
                    <h2 class="fw-semibold"><?php echo e(__('Blog Posts')); ?></h2>
                    <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area)..')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <section id="blog-posts">
        <div class="container">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item">
                    <div class="row">
                        <div class="col-lg-3 col-12 mb-3">
                            <img class="img-thumbnail" src="<?php echo e(url('storage/posts_thumbnails/' . $post->getThumbnailFileName())); ?>"
                                 alt="Blog post thumbnail">
                        </div>
                        <div class="col-lg col-12 right-side mb-4">
                            <h3><?php echo e($post->getTitle()); ?></h3>
                            <p><?php echo split_paragraph(strip_tags($post->getDescription()),0.6,30); ?></p>
                            <a href="<?php echo e(route('pages.post', ['id' => $post->getId()])); ?>" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <nav aria-label="Page navigation example" class="d-flex pagination-wrapper">
                <ul class="pagination mx-auto">
                    <?php if($posts->links()->paginator->currentPage() > 1): ?>
                        <li class="page-item next">
                            <a class="page-link"
                               href="<?php echo e(route('pages.blog')); ?>?page=<?php echo e($posts->links()->paginator->currentPage() - 1); ?>">Back</a>
                        </li>
                    <?php endif; ?>
                    <?php $__currentLoopData = $posts->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item">
                            <a
                                class="page-link <?php echo e($posts->links()->paginator->currentPage() === intval(explode('=', $link)[1]) ? 'active' : ''); ?>"
                                href="<?php echo e($link); ?>"><?php echo e(explode('=', $link)[1]); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($posts->links()->paginator->lastPage() > $posts->links()->paginator->currentPage()): ?>
                        <li class="page-item next">
                            <a class="page-link"
                               href="<?php echo e(route('pages.blog')); ?>?page=<?php echo e($posts->links()->paginator->currentPage() + 1); ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/client/blog.blade.php ENDPATH**/ ?>