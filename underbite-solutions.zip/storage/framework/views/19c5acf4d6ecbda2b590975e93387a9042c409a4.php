<?php
  /** @var $post \App\Models\Post */
  /** @var $countries \App\Models\Country[] */
?>


<?php $__env->startSection('title'); ?>
  Edit Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger mb-3"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <h2>Update Post</h2>
  <form action="<?php echo e(route('admin.posts.update', ['post' => $post])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group mb-3">
      <label for="titleInput" class="form-label">Title</label>
      <input id="titleInput"
             name="title"
             class="form-control"
             placeholder="Place your title here"
             value="<?php echo e($post->getTitle()); ?>"
             required>
    </div>

    <div class="form-group mb-3">
      <label for="editor" class="form-label">Description</label>
      <textarea id="editor"
                name="description"
                class="form-control"
                placeholder="Place your post here"><?php echo e($post->getDescription()); ?></textarea>
    </div>

    <div class="form-group mb-3">
      <label for="lang" class="form-label">Language</label>
      <select name="lang" id="lang" class="form-select">
        <option>Select Language</option>
        <option value="en" <?php echo e($post->getLang() === 'en' ? 'selected' : ''); ?>>English</option>
        <option value="fr" <?php echo e($post->getLang() === 'fr' ? 'selected' : ''); ?>>French</option>
        <option value="ar" <?php echo e($post->getLang() === 'ar' ? 'selected' : ''); ?>>Arabic</option>
      </select>
    </div>

    <div class="form-group mb-3">
      <label for="authorNameInput" class="form-label">Author</label>
      <input id="authorNameInput"
             name="author_name"
             class="form-control"
             placeholder="Place your author name here"
             value="<?php echo e($post->getAuthorName()); ?>"
             required>
    </div>

    <div class="mb-3">
      <label for="formFile" class="form-label">Thumbnail</label>
      <input class="form-control" type="file" id="formFile" name="thumbnail" accept="image/*">
    </div>

    <button class="btn btn-primary"><i class="fa fa-paper-plane"></i> Update</button>
    <button class="btn btn-secondary" type="reset"><i class="fa fa-eraser"></i> Reset</button>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
  <script>
    ClassicEditor
      .create(document.querySelector('#editor'))
      .then(editor => {
        console.log(editor);
      })
      .catch(error => {
        console.error(error);
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.auth-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>