<?php
    /** @var $posts \Illuminate\Database\Eloquent\Collection|\App\Models\Post[] */
?>


<?php $__env->startSection('title'); ?>
    Posts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col">
            <h2>Posts List</h2>
        </div>
        <div class="col">
            <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary float-end"><i class="fa fa-plus"></i> Add Post</a>
        </div>
    </div>
    <table class="table table-hover">
        <tr>
            <th>#</th>
            <th>Title</th>
            <th>Description</th>
            <th>Thumbnail</th>
            <th>Lang</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($post->getTitle()); ?></td>
                <td><?php echo e(\Illuminate\Support\Str::limit(strip_tags($post->getDescription()), 50)); ?></td>
                <td><a href="<?php echo e(url('storage/posts_thumbnails/' . $post->getThumbnailFileName())); ?>" target="_blank">Link</a></td>
                <td><?php echo e($post->getLang()); ?></td>
                <td>
                    <a class="btn btn-sm btn-secondary border-0" href="<?php echo e(route('admin.posts.edit', ['post' => $post])); ?>"><i class="fa fa-pencil"></i> Edit</a>
                    <form action="<?php echo e(route('admin.posts.delete', ['post' => $post])); ?>" method="POST"
                          class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger border-0"><i class="fa fa-trash"></i> Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.auth-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>