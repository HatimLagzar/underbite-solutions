<?php $__env->startSection('title'); ?>
    <?php echo e(__('About Us')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="about-us" style=" padding-top: 45px;  padding-bottom: 45px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <h3 class="fw-light mb-1"><?php echo e(__('Dental Surgery')); ?></h3>
                    <h2 class="fw-semibold"><?php echo e(__('Explained')); ?></h2>
                    <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area).')); ?></p>
                    <div class="row">
                        <p class="col-12"><?php echo e(__('To the general public, dentistry and dental surgery are mostly associated with fixing teeth. However, dental medicine isn’t only about fixing your teeth but also covers other aspects of craniofacial complex root.')); ?></p>
                        
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <a href="/#form-wrapper"
                           class="btn btn-light px-5 shadow rounded-5 apply mt-4"><?php echo e(__('Apply & Meet Us')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="proud-members">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-12">
                    <h3><span class="text-pink fw-normal">Proud</span><span class="text-blue fw-bold">Members</span>
                    </h3>
                    <p><?php echo e(__('DentiCare prouds itself of being one empowered manufactured products whereas parallel platforms. Holisticly predominate extensible testing procedures.')); ?></p>
                </div>
                <div class="col-lg d-none d-lg-block"></div>
                <div class="col-lg-5 col-12">
                    <div class="row mb-3">
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                        <div class="col">
                            <img src="/images/about_us.jpeg" alt="Doctors">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/client/about.blade.php ENDPATH**/ ?>