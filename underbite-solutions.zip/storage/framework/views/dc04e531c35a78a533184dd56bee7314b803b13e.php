<?php $__env->startSection('title'); ?>
  <?php echo e(__('Contact Us')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <section id="contact-us-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <h3 class="fw-light mb-1"><?php echo e(__('Dental Surgery')); ?></h3>
          <h2 class="fw-semibold"><?php echo e(__('Contact us')); ?></h2>
          <p><?php echo e(__('Dental surgery is a part of dentistry, which is a branch of medicine dealing with teeth, gums, and the mouth. This covers the oral mucosa and the dentition as well as all related tissues and structures (like the jaw and facial or maxillofacial area)...')); ?></p>
        </div>
      </div>
    </div>
  </section>

  <section id="contact-us-section">
    <div class="container">
      <div class="row">
        <div class="col-6"></div>
        <div class="col-lg-6 col-12">
          <form id="contact-us-form" action="#" method="post">
            <h1 class="mb-3 text-center"><?php echo e(__('Get in touch with us')); ?></h1>
            <div class="row">
              <div class="form-group col-12 col-lg-6 mb-3">

                <input id="firstNameInput" placeholder="<?php echo e(__('First Name')); ?>" type="text" class="form-control">
              </div>
              <div class="form-group col-12 col-lg-6 mb-3">

                <input id="lastNameInput" placeholder="<?php echo e(__('Last Name')); ?>" type="text" class="form-control">
              </div>
            </div>
            <div class="row">
              <div class="form-group col-12 col-lg-6 mb-3">

                <input id="subjectInput" placeholder="<?php echo e(__('Subject')); ?>" type="text" class="form-control">
              </div>
              <div class="form-group col-12 col-lg-6 mb-3">

                <input id="emailAddress" placeholder="<?php echo e(__('Email Address')); ?>" type="email" class="form-control">
              </div>
            </div>
            <div class="row">
              <div class="form-group col-12 mb-3">

                <textarea id="messageInput" placeholder="<?php echo e(__('Message')); ?>" type="text" rows="4" class="form-control"></textarea>
              </div>
            </div>
              <div class="d-flex justify-content-center align-items-center">
                  <button class="btn btn-primary rounded-5 d-block"><?php echo e(__('Send')); ?></button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section id="our-dental-service">
    <h3 class="text-center text-pink fw-light mb-1"><?php echo e(__('Our Dental Service')); ?></h3>
    <h2 class="text-center fw-semibold"><?php echo e(__('Professionals')); ?></h2>
    <p class="text-center text-muted w-50 mx-auto mb-5"><?php echo e(__('Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate e-business applications through  revolutionary catalysts for change. Seamlessly underwhelm optimal testing processes....')); ?></p>

    <div class="container">
      <div class="row px-lg-5">
        <div class="col-lg-3 col-6">
          <img src="/images/icons/thumbs-up.png" alt="Thumbs up">
          <p class="fw-semibold text-center"><?php echo e(__('Patient Satisfaction')); ?></p>
        </div>
        <div class="col-lg-3 col-6">
          <img src="/images/icons/check-up.png" alt="Check Up">
          <p class="fw-semibold text-center"><?php echo e(__('Dental Success')); ?></p>
        </div>
        <div class="col-lg-3 col-6">
          <img src="/images/icons/plane.png" alt="Plane">
          <p class="fw-semibold text-center"><?php echo e(__('Travel Satisfaction')); ?></p>
        </div>
        <div class="col-lg-3 col-6">
          <img src="/images/icons/recovery.png" alt="Recovery">
          <p class="fw-semibold text-center"><?php echo e(__('Quick Recovery')); ?></p>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('js/pages/contact-us.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\underbite-solutions\resources\views/client/contact-us.blade.php ENDPATH**/ ?>