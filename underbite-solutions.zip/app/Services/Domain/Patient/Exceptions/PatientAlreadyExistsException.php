<?php

namespace App\Services\Domain\Patient\Exceptions;

use Exception;

class PatientAlreadyExistsException extends Exception
{

}