<?php

namespace App\Services\Domain\Auth\Exceptions;

use Exception;

class IncorrectCredentialsException extends Exception
{
}