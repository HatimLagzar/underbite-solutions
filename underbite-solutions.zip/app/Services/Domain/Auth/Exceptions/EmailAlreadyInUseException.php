<?php

namespace App\Services\Domain\Auth\Exceptions;

use Exception;

class EmailAlreadyInUseException extends Exception
{
}